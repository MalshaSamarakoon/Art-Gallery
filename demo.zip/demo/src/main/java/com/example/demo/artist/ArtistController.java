package com.example.demo.artist;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.category.Category;
import com.example.demo.category.CategoryRepository;
import com.example.demo.login.Login;
import com.example.demo.login.LoginRepository;
import com.example.demo.product.Product;

@Controller
public class ArtistController {

	
	@Autowired 
	private ArtistRepository artistRepo;
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Autowired
	private LoginRepository loginRepo;
	
	
	@GetMapping("/artists")
	public String showArtitList(Model model) {
        List<Artist> listArtists = artistRepo.findAll();

		model.addAttribute("listArtists", listArtists);
				
				return "artists";
	}
	
	@GetMapping("/artists/new")
	public String showCreateArtistForm(Model model) {
		List<Category> listCategories = categoryRepo.findAll();
		model.addAttribute("listCategories", listCategories);
		
		List<Login> listLogins = loginRepo.findAll();
		model.addAttribute("listLogins", listLogins);
		
		model.addAttribute("artist", new Artist());
		
//		new
	    model.addAttribute("login", new Login());
//new close		
		
		return "artist_form";
	}
	
	
	
	@PostMapping("artists/save")
	public String saveArtist(Artist artist, @ModelAttribute Login login) {
		
		if(login.getRegnum() == ""){
			artistRepo.save(artist);
        }
        else{
            Login temp =  loginRepo.save(login);
            artist.setLogin(temp);
            artistRepo.save(artist);
        }
		
		
		artistRepo.save(artist);
		
		return "redirect:/artists";
	}
	
	

	@GetMapping("artists/edit/{id}")
	public String showEditArtistsForm(@PathVariable("id") Integer id, Model model) {
		Artist artist = artistRepo.findById(id).get();

		model.addAttribute("artist", artist);

List<Category> listCategories= categoryRepo.findAll();

model.addAttribute("listCategories", listCategories);
	
		
		
		return "artist_form";
	}
	
	
	@GetMapping("artists/delete/{id}")
	public String deleteProduct(@PathVariable("id") Integer id, Model model) {
		artistRepo.deleteById(id);

return "redirect:/artists"; 
	}
	
	
	
}
