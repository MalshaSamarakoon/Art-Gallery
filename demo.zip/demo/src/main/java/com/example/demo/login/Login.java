package com.example.demo.login;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.example.demo.artist.Artist;

@Entity
@Table(name="login")

public class Login {
	
	@Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name = "id")
    private Integer id;
	
	@Column(length = 100, nullable = false, unique = true)
    private String username;
    
	private String password;
	
	
    private String regnum;

	
	@OneToOne(mappedBy = "login")
	private Artist artist;
	

public Artist getArtist() {
		return artist;
	}

	public void setArtist(Artist artist) {
		this.artist = artist;
}

public Login()
 {
		
}

//public Login(Integer id, String username, String password) {
//		
//		this.id = id;
//		this.username = username;
//		this.password = password;
//	}
	

	public Integer getId() {
	    return id;
	}
	public Login(Integer id, String username, String password, String regnum ) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.regnum = regnum;
	}
	
	
	

	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getRegnum() {
		return regnum;
	}

	public void setRegnum(String regnum) {
		this.regnum = regnum;
	}
	
	
}