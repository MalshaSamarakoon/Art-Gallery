package com.example.demo.login;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.artist.Artist;
import com.example.demo.artist.ArtistRepository;
import com.example.demo.category.Category;
import com.example.demo.category.CategoryRepository;
import com.example.demo.product.Product;

@Controller
public class LoginController {

	
	@Autowired
    private LoginService userService;

    
	@Autowired
	private LoginRepository loginRepo;
	
	@Autowired
	private ArtistRepository artistRepo;
	
	
    @GetMapping("/login")
           
    public ModelAndView login() {
    	ModelAndView mav = new ModelAndView("login");
        mav.addObject("user", new Login());
        return mav;
    }
    

    @PostMapping("/login")
    public String login(@ModelAttribute("user") Login user ) {
    	
    	Login oauthUser = userService.login(user.getUsername(), user.getPassword());
    	

    	System.out.print(oauthUser);
    	if(Objects.nonNull(oauthUser)) 
    	{	
  
    		return "redirect:/home";
    	
    		
    	} else {
    		return "redirect:/login";
    		
    	
    	}

}
    
    @RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
    public String logoutDo(HttpServletRequest request,HttpServletResponse response)
    {
    	
	  
        return "redirect:/login";
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @GetMapping("/register/new")
	public String showNewProductForm(Model model) {
		List<Artist> listArtists= artistRepo.findAll();
		
		model.addAttribute("login", new Login());
		model.addAttribute("listArtists", listArtists);
		
		return "register";
	}
	
	@PostMapping("/register/save")
	public String saveLogin(Login login) {
		loginRepo.save(login);
		
		return "redirect:/register";
	}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}