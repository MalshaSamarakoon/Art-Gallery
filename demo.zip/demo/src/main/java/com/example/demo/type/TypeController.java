package com.example.demo.type;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.category.Category;
import com.example.demo.category.CategoryRepository;
import com.example.demo.product.Product;

@Controller
public class TypeController {
	
	@Autowired
	private TypeRepository typeRepo;
	
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@GetMapping("/types/new")
	public String showCreateNewTypeForm(Model model) {
		List<Category> listCategories= categoryRepo.findAll();
	
		model.addAttribute("listCategories", listCategories);
		model.addAttribute("type" , new Type());
		
		return "type_form";
	}
	
	@PostMapping("/types/save")
	public String saveType(Type type) {
		typeRepo.save(type);
		return "redirect:/types";
	}

	@GetMapping("/types")
	public String listTypes(Model model) {
		List<Type> listTypes = typeRepo.findAll();
		model.addAttribute("listTypes",listTypes );
		
	return "types";
	}

	
	@GetMapping("types/delete/{id}")
	public String deleteType(@PathVariable("id") Integer id, Model model) {
typeRepo.deleteById(id);

return "redirect:/types"; 
	}
	
	
	
}
